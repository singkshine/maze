#ifndef CUCULATE_H
#define CUCULATE_H
#include<stdlib.h>
#include<time.h>
#include <iostream>
#include <stack>
#include<time.h>
#include"drawline.h"
#include<unistd.h>
//class cuculate
//{
//	public:
//	
//	protected:
//};
#define Cantmove 2
#define Couldmove 0
#define Pass 1
void dim(int serchDefine);//just used to serch the define;
#define Upmove 1
#define Leftmove 2
#define Downmove 3
#define Rightmove 4
#define Tbranch 1
#define Fbranch 0
typedef struct cellmessage{
	int x;
	int y;
	int numb;
	int type;
//	int isbranch;	

} Cell;// x y is the mached block Topleft location

void maincucul(int len,int wide){
	
		Cell block[len][wide];//i+1 ,j+1 is the now cell
	int i=0,j=0;

	for(i=0,j=0;i<len;i++){	
		for(j=0;j<wide;j++){
		block[i][j].x=i;
		block[i][j].y=j;
		block[i][j].numb=0;
		block[i][j].type=Couldmove;
		
	//	block[i][j].isbranch=Fbranch;
		}
	}
	
	
	std::stack <int> stepx;
	std::stack <int> stepy;
	srand(time(NULL));
	int a=rand()%(len-1);
	int b=rand()%(wide-1);
	
	stepx.push(a);
	stepy.push(b);//the 
	
	block[a][b].type=Pass;
	
	//lock block

	//the wrong is on the time when y=0 ,it could not be print
//	printf("block%d\n",block[a][b].type);

	
		
	int step=1;
	int turns=0;
	int turn[4]={0,0,0,0};
	int numbers=0;


///




/// muse prpduce++++++++++++++++++++++++++++++++++++++
	int randto=0;
	for(;step<len*wide;){
	usleep(600);
		randto=rand()%4+1;
		while(randto==turn[0]||randto==turn[1]||randto==turn[2]||randto==turn[3]){
			randto=rand()%4+1;	
		}
		int ismove=0;
		switch(randto){
			case Leftmove:{
				if(a-1<0){//is out of lim ?
					turn[turns]=Leftmove;
					turns++;
				}else{//is it lock?
					if(block[a-1][b].type!=Couldmove){
						turn[turns]=Leftmove;
						turns++;
					}else{
						clrline(a,b,Leftmove);//clr
						a=a-1;
						ismove=1;
						for(;turns>=0;turns--){//reset
							turn[turns]=0;
						}turns=0;
						step++;//steplen
					}
				}
				break;
			}
			case Rightmove:{
				if(a+1>len-1){//is it out of lime?
					turn[turns]=Rightmove;
					turns++;
				}else{//is it lock?
					if(block[a+1][b].type!=Couldmove){
						turn[turns]=Rightmove;
						turns++;
					}else{
						clrline(a,b,Rightmove);//clr
						a=a+1;
						ismove=1;
						for(;turns>=0;turns--){
							turn[turns]=0;
						}turns=0;//reset
						
						step++;//steplen
					}
				}
				break;
			}
			case Upmove :{
				if(b-1<0){// is it out  of Lim?
					turn[turns]=Upmove;
					turns++;
				}else{//is it lock?
					if(block[a][b-1].type!=Couldmove){
						turn[turns]=Upmove;
						turns++;
					}else{
						clrline(a,b,Upmove);
						b=b-1;
						ismove=1;
						for(;turns>=0;turns--){
							turn[turns]=0;
						}turns=0;
						step++;
					}
				}
				break;
			}
			case Downmove :{
					if(b+1>wide-1){//wide out of Lim
					turn[turns]=Downmove;
					turns++;
				}else{
					if(block[a][b+1].type!=Couldmove){
						turn[turns]=Downmove;
						turns++;
					}else{
						clrline(a,b,Downmove);
						b=b+1;
						ismove=1;
						for(;turns>=0;turns--){
							turn[turns]=0;
						}turns=0;					
						step++;
					}
				}
				break;
			}		
		}
		if(ismove==1){
			stepx.push(a);
			stepy.push(b);
			block[a][b].type=Pass;//clr wall
			block[a][b].numb=numbers+1;numbers++;
		}
		if(turns==4){
			
				for(;turns>=0;turns--){
					turn[turns]=0;
				}turns++;
				int result=0;
				if(stepx.size()>0){
				
					stepx.pop();
					stepy.pop();
					a=stepx.top();
					b=stepy.top();
					numbers--;
				}
			/*	if(stepx.size()==1){
					printf("step%d\n",step);
					printf("close\n");
					break;
				}
				printf("backlast\n");  */
			}
	}
	// search road ;
	
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	
//	printf("push ‘RETURN’ to solve\n");
//	printf("push '0' to close exe\n");
//	char * string=NULL;
	//here could add judg and component system 
	// using a function to make it come true
	
	
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++
	//search road 
	system("cls");
	int x1=0,y1=0,x2=len-1,y2=wide-1;
	printf("put a front to tail\n");
	printf("the leftup first block is '1 1',the rightdown block is %d %d\n",len,wide);
	printf("x1 y1\n");
	std::cin>>x1;x1--;
	std::cin>>y1;y1--;
	printf("x2 y2\n");
	std::cin>>x2;x2--;
	std::cin>>y2;y2--;
	int front =block[x1][y1].numb;
	int tail =block[x2][y2].numb;
	std::stack <int> movex;
	std::stack <int> movey;
	movex.push(x1);
	movey.push(y1);
	block[x1][y1].type=Cantmove;
	while(x1!=x2||y1!=y2){
		
		int i=0,ismove=0;
		for(i=1;i<=4;i++){
			switch(i){
				case Leftmove:{
					if(x1-1>=0){
						if(block[x1-1][y1].type!=Cantmove){
							if(block[x1-1][y1].numb==front-1||block[x1-1][y1].numb==front+1){
								x1=x1-1;
								movex.push(x1);
								movey.push(y1);
								block[x1][y1].type=Cantmove;
								ismove=1;
							}
						}
					}
				
					break;
				}
				case Rightmove:{
					if(x1+1<=len-1){
						if(block[x1+1][y1].type!=Cantmove){
							if(block[x1+1][y1].numb==front-1||block[x1+1][y1].numb==front+1){
								x1=x1+1;
								movex.push(x1);
								movey.push(y1);
								block[x1][y1].type=Cantmove;
								ismove=1;
							}
						}
					}
					break;
				}
				case Downmove:{
					if(y1+1<=wide-1){
						if(block[x1][y1+1].type!=Cantmove){
							if(block[x1][y1+1].numb==front-1||block[x1][y1+1].numb==front+1){
								y1=y1+1;
								movex.push(x1);
								movey.push(y1);
								block[x1][y1].type=Cantmove;
								ismove=1;
							}
						}
					}
					break;
				}
				case Upmove:{
					if(y1-1>=0){
						if(block[x1][y1-1].type!=Cantmove){
							if(block[x1][y1-1].numb==front-1||block[x1][y1-1].numb==front+1){
								y1=y1-1;
								movex.push(x1);
								movey.push(y1);
								block[x1][y1].type=Cantmove;
								ismove=1;
							}
						}
					}
					break;
				}
			}
			front=block[x1][y1].numb;
			if(ismove==1){
				break;
			}
		}
		if(ismove==1){
			continue;
		}
		else{
			
			movex.pop();
			movey.pop();
			x1=movex.top();
			y1=movey.top();
			front=block[x1][y1].numb;
		}
		
	}
	
	
	
	//+++++++++++++++++++++++++++++++++++++++++++++++++	//	std::cin>>string;
	//	if(string=="RETURN"){
	//we fine a inportant detall 
	//from small numb to big numb may have over 2 way(road)
	//but from big numb to small numb only have a way;no no no 
	//last message is wrong ;
	//if the two block on two branch deferent block;
	//this is wrong************
	
	//ok i think out a way to solve it;
	//we can do these :
	//search this branch which front is on it;
	//if front < tail
	//this situation  we search the block whitch just bigger 1 than front ;
	//search to the block.numb == tail;   *********1
	//if this block != tail ,block this branch ,back to the block where branch produce;
	//other situation, just like this situation ,pointed end (the last block on this branch)
	//whitch is smaller than tail;
	//then like 1 -----;
	
	
	//if front >branch 
	// search smaller block ;
	//if do not find tail;
	//also block this branch ;
	
	
	//if front =branch 
	//search smaller block 
	//block this branch 
	
	
	
	
	
	//other thought
	//why not find 0 in all block first
	//then use search to find two block(front ,tail)
	//then use que(dui lie)to get push(tail);
	//and conbine two stack ,use que and stack to conbine;
	
	
	//other way may let this process easier
	//difine branch in block[][]
	//we could find the block where branch was produced;
	//try a struct to storage blcok[][];
	
	
	
	
	
	
	
	
	
	
	
	//IF the first plase is the pointed end of branch 
	//it will null

			
	//	}
	//	else if(string=="0"){
	//		break;
	//	}
		
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	//road print 
	//using stack storage pass block 
	
	
	
	
	while(movex.size()!=0){
		usleep(10000);
		passdraw(movex.top(),movey.top());
		movex.pop();
		movey.pop();
		
	}

	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
}



//if set wall in *block ,then there will have a way to solve How to mark cell location
//is we need to mark cell block?
//but in this way ,we should math over doublie location to storage wall;
//is it really warth to do it ?
//

//new view 
// we can dim the orignal cell of four void* (L ,R ,U ,D ) toword (->) NULL;
//and use i,j the location relationship to move the way 
//then arfter move ,every cell four void*(L,R,U,D) will toword next cell
//the way is hiding in the toward ;
//ok let's do it;;






//if not set wall in *block ,how to slove the way to in the end to serch a way connect exit and enter 



#endif