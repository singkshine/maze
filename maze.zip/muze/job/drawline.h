
#include <conio.h> 
#include <graphics.h>
#include <iostream>


#ifndef BLOCKLEN//define block size
#define BLOCKLEN 20 //the block of maze size
#define Upmove 1
#define Leftmove 2
#define Downmove 3
#define Rightmove 4
#endif


#ifndef MUZZ_BK
#define MUZZ_BK
void muzebk(int len,int wide){
	
	int a=len*BLOCKLEN,b=wide*BLOCKLEN;
	initgraph(a,b); 
	fillrectangle(0,0,a,b);
	int i=0;
	for(i=0;i<len;i++){
		setlinecolor(BLACK);
		int x1=i*BLOCKLEN,x2=x1;
		int y1=0,y2=wide*BLOCKLEN;
		line(x1,y1,x2,y2);
	}
	for(i=0;i<wide;i++){
		setlinecolor(BLACK);
		int x1=0,x2=len*BLOCKLEN;
		int y1=i*BLOCKLEN,y2=y1;
		line(x1,y1,x2,y2);
	}

	
	
	
	
}
void clrline(int x,int y,int whrtocls){//please pass the cell before go to next block
	setlinecolor(WHITE);
	int lenth =BLOCKLEN;	
switch(whrtocls){
		case Upmove:{
			line(x*lenth,y*lenth,(x+1)*lenth,y*lenth);
			break;
		}
		case Leftmove:{			
			line(x*lenth,y*lenth,x*lenth,(y+1)*lenth);
			break;
		}
		case Downmove:{
			line(x*lenth,(y+1)*lenth,(x+1)*lenth,(y+1)*lenth);
			break;
		}
		case Rightmove:{
			line((x+1)*lenth,y*lenth,(x+1)*lenth,(y+1)*lenth);
			break;
		}
	}

}


void passdraw(int x,int y){
	setlinecolor(BLUE);//   chose color for "X"
	int offset = BLOCKLEN/10;
	line(x*BLOCKLEN+offset,y*BLOCKLEN+offset,(x+1)*BLOCKLEN-offset,(y+1)*BLOCKLEN-offset);
	line((x+1)*BLOCKLEN-offset,y*BLOCKLEN+offset,x*BLOCKLEN+offset,(y+1)*BLOCKLEN-offset);
}
#endif


		
		












