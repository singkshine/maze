#include <iostream>
#include<stdio.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
// by Mr.singk
#include <conio.h> 
#include <graphics.h> 
#include"cuculate.h"
#include"drawline.h"


// if the gcc can't run these file on your Devc++
//please check easyx.h and graphic.h whether included in the lib of your gcc 
//if still can't
//please replace likes #include "cuculate.h"  to #include "File location named 'cuculate.h' in your sourse manager "
//if you have any question please get in touch  with me by QQ:2962571236


//you could add timer in cuculate every cycle to low the speed of muze produce and road search

int main(int argc, char** argv) {
		printf("Please input size of muze len wide likes 'A B'\n");
		
	int len;
	std::cin>>len;
	int wide;
	std::cin>>wide;
	muzebk(len,wide);

	
	maincucul(len,wide);
	

	printf("HEAR");
	
	getch(); 
	closegraph(); 
	return 0;
}